param(
    [ValidateSet("DEV","TEST","PROD")]
    [parameter(mandatory=$true)]
    [string]$Environment = ("DEV","TEST","PROD")
)

$path = (Get-Location).Path
$timestamp = Get-Date

if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null) 
{
    Add-PSSnapin "Microsoft.SharePoint.PowerShell"
}

Start-SPAssignment -global
Start-Transcript -Path "$($path)\ASD-Deployment.log" -Force

$timestamp = Get-Date
$path = (Get-Location).Path
$hostName = $env:COMPUTERNAME
# $hostNameSuffix = $hostName.Remove(0,$hostName.Length-2)
$Environments = @{
     "DEV" =
    @{
       "WebAppUrl" = "https://$($hostName).ferc.gov"
       "WebSiteUrl" = "https://$($hostName).ferc.gov/asd"
       "SQLInstance" = "SPSQL"
       "SQLBackupDir" = "F:\SQLBackups"
     }
    "TEST" = 
    @{
        "WebAppUrl" = "https://test.sp.ferc.gov/"
        "WebSiteUrl" = "https://test.sp.ferc.gov/asd"
        "SQLInstance" = "SPSQL"
        "SQLBackupDir" = "F:\SQLBackups"
     }
     "PROD" = 
     @{
      "WebAppUrl" = "https://sp.ferc.gov/"
      "WebSiteUrl" = "https://sp.ferc.gov/asd"
      "SQLInstance" = "SPSQL"
      "SQLBackupDir" = "F:\SQLBackups"
     }
}

$WebSiteUrl = $Environments.Get_Item($Environment).WebSiteUrl;


function backupContentDB() {
    Write-Output "Backing up ASD Content DB..."

    $instance = $Environments.Get_Item($Environment).SQLInstance;
    $localPath = "F:\SQLBackups"
    $dbName = "WFED1_Content_ASD"
    $backupFilePath = $localPath + "\" + $dbName + ".bak"

    Backup-SqlDatabase -ServerInstance $instance -Database $dbName -BackupAction Database -BackupFile $backupFilePath -Compression On -Initialize
    Write-Output "Backup of ASD Content DB is complete."
}

function addSCsToCTs() {
    Write-Output "Adding new field to ASD Base Content Type."    
    $newFieldSchema = '<Field Type="Boolean" DisplayName="SysIsAwarded" EnforceUniqueValues="FALSE" Indexed="FALSE" ID="{34f43612-3830-4750-9457-86bb7b7cfbfd}" StaticName="SysIsAwarded" Name="SysIsAwarded" Group="ASD Columns"><Default>0</Default></Field>'
    $web.Fields.AddFieldAsXml($newFieldSchema) | Out-Null
    $web.update()
    
    $field = $web.Fields["SysIsAwarded"] #| Out-Null
    $ctName = "ASD Base"
    $link = new-object Microsoft.SharePoint.SPFieldLink $field
    $ct = $web.ContentTypes[$ctName]
    $ct.FieldLinks.Add($link)
    $ct.Update($true)
    Write-Output "New field SysIsAwarded was added to ASD Base Content Type."

    $scs = @("Funding", "Notice of Intent", "Recompete Package")
    $cts = @("Product", "Product With Incidental Services", "Services", "BPA Call Or Task Delivery Order", "Exercising an Option Year")

    foreach($sc in $scs) {
        $field = $web.Fields[$sc]

        foreach($ctName in $cts) {
            $link = new-object Microsoft.SharePoint.SPFieldLink $field
            
            $ct = $web.ContentTypes[$ctName]
            Write-Output "Adding $($sc) to $($ct.name)"
            $ct.FieldLinks.Add($link)
            $ct.Update($true)
        }
    }
}

function enforceUniqueColumn() {
    Write-Output "Setting Acquisition Assistance Form # for unique values."
    $acqList = $web.Lists["Acquisition Assistance"]
    $title = $acqList.Fields.GetFieldByInternalName("Title");  

    $title.Indexed = $true;
    $title.Update();
    $title.EnforceUniqueValues = $true;
    $title.Update();
    Write-Output "Finished setting Acquisition Assistance Form # for unique values."
}

function spacer() {
    Write-Host "`r`n******************************`r`n"
}


Write-Output "Start time: $($timestamp)"
Write-Output "Deploying to $($WebSiteUrl)`r`n"

try {
    $web = Get-SPWeb $WebSiteUrl

    spacer

    backupContentDB

    spacer

    $asd = Get-ChildItem "$($path)\WSPs" -filter "ASD_v2.wsp"
    
    Write-Output "Deploying $($asd.Name)"

    Add-SPUserSolution -LiteralPath $asd.FullName -Site $WebSiteUrl
    Update-SPUserSolution -Identity "ASD.wsp" -Site $WebSiteUrl -ToSolution $asd.Name 

    Write-Output "Successfully deployed: $($asd.Name)`r`n"

    $wsps = Get-ChildItem "$($path)\WSPs" -filter "*.wsp" | ? {$_.Name -ne "ASD_v2.wsp"}
    foreach( $wsp in $wsps ) {
        Write-Output "Deploying $($wsp.Name)"

        Add-SPUserSolution -LiteralPath $wsp.FullName -Site $WebSiteUrl | Out-Null
        Install-SPUserSolution -Identity $wsp.Name -Site $WebSiteUrl | Out-Null

        Write-Output "Successfully deployed: $($wsp.Name)`r`n"
    }

    spacer

    # Enable Sandbox features
    $featureGuids = @(
        "736b9ef4-e738-4fbb-b692-1bd057f29fc2",
        "2f30afc6-f0ff-47e6-8fcc-4067a7d9b49c",
        "63dc88f0-85f7-4b85-bf98-833cfa83a201",
        "5ad2865f-5263-4f1f-94b6-10563c538939"
    )

    Write-Output "Enabling features..."
    foreach($guid in $featureGuids) {
        Enable-SPFeature -Identity $guid -Url $WebSiteUrl
    }
    Write-Output "Features enabled."

    spacer

    Write-Output "Adding site columns to content types..."
    #start-process powershell -argument "$($path)\POSH\AddSCsToCTs.ps1" -Wait
    #& "$($path)\POSH\AddSCsToCTs.ps1 -Environment $Environment" 

    #$proc = Start-Process powershell -ArgumentList "-Environment $Environment" -Passthru
    #do {start-sleep -Milliseconds 500}
    #until ($proc.HasExited)
    addSCsToCTs

    Write-Output "Adding site columns to content types is finished."
    
    spacer

    # ASD Workflow Feature
    Write-Output "Enabling ASD Workflow..."
    Enable-SPFeature -Identity "09deeefb-3454-4dc2-8ceb-9dd3b634ae04" -Url $WebSiteUrl
    Write-Output "ASD Workflow enabled."

    spacer

    enforceUniqueColumn
    
    spacer
} catch [system.exception] {
    Write-Output $_.Exception.Message
} finally {
    $timestamp = Get-Date
    Write-Output "`r`n`r`nEnd time: $($timestamp)"

    Stop-Transcript
    Stop-SPAssignment -global
}