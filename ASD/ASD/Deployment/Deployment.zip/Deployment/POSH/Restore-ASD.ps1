﻿param(
    [ValidateSet("DEV","TEST","PROD")]
    [parameter(mandatory=$true)]
    [string]$Environment = ("DEV","TEST","PROD")
)

$timestamp = Get-Date
$path = (Get-Location).Path
$hostName = $env:COMPUTERNAME
# $hostNameSuffix = $hostName.Remove(0,$hostName.Length-2)
$Environments = @{
     "DEV" =
    @{
       "WebAppUrl" = "https://$hostName.ferc.gov"
       "WebSiteUrl" = "https://$hostName.ferc.gov/asd"
       "SQLInstance" = "SPSQL"
       "SQLBackupDir" = "F:\SQLBackups"
     }
    "TEST" = 
    @{
        "WebAppUrl" = "https://test.sp.ferc.gov/"
        "WebSiteUrl" = "https://test.sp.ferc.gov/asd"
        "SQLInstance" = "SPSQL"
        "SQLBackupDir" = "F:\SQLBackups"
     }
     "PROD" = 
     @{
      "WebAppUrl" = "https://sp.ferc.gov/"
      "WebSiteUrl" = "https://sp.ferc.gov/asd"
      "SQLInstance" = "SPSQL"
      "SQLBackupDir" = "F:\SQLBackups"
     }
}

$sqlPath = $Environments.Get_Item($Environment).SQLBackupDir;
$dbName = "WFED1_Content_ASD"
$restoreFilePath = $sqlPath + "\" + $dbName + ".bak"
$instance = $Environments.Get_Item($Environment).SQLInstance;
$webApplication = $Environments.Get_Item($Environment).WebAppUrl

Start-Transcript -Path "$path\Restore-ASD.log" -Force
Write-Output "Start time: $($timestamp)`r`n`r`n"

try {
    Write-Output "Restoring ASD DB..."
    Restore-SqlDatabase -ServerInstance $instance -Database $dbName -BackupFile $restoreFilePath
    Mount-SPContentDatabase "WFED1_Content_ASD" -DatabaseServer "SPSQL" -WebApplication $webApplication
    Write-Output "Restore finished."
} catch [system.exception] {
    Write-Output $_.Exception.Message
} finally {
    $timestamp = Get-Date
    Write-Output "`r`n`r`nEnd time: $($timestamp)"

    Stop-Transcript
}